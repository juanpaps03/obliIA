# %%
from datetime import datetime
from GameBoard import GameBoard
from Agent import Agent
from Minimax_Agent import MinimaxAgent
import numpy as np


# %%
def check_win(board: GameBoard):
    return board.get_max_tile() >= 2048

int_to_string = ['UP', 'DOWN', 'LEFT', 'RIGHT']

# %%
def run_game():
    agent: Agent = MinimaxAgent()
    board: GameBoard = GameBoard()
    done = False
    moves = 0
    
    while not done:        
        action = agent.play(board)
        done = board.play(action)
        done = done or check_win(board)
        moves += 1
    print(f"Max tile: {board.get_max_tile()}")
    if check_win(board):
        print("WON THE GAME!!!!!!!!")
    else:
        print("BOOOOOOOOOO!!!!!!!!!")
    return check_win(board)

# %% [markdown]
# ### Ejecucion del agente minimax con 100 juegos, heuristica compuesta, poda al 4 nivel del arbol y considerando 5 casillas libres randomicamente.

# %%
winrate = 0
count = 0
games = 100
for i in range(games):
    won = run_game(True)
    count += 1
    winrate += 1 if won else 0

print(f"El winrate obtenido con {count} ejecuciones es de: {(winrate*100)/games}")


# %% [markdown]
# ## Pruebas de memoización

# %%
def run_game(use_memo: bool = True):
    agent: Agent = MinimaxAgent()
    board: GameBoard = GameBoard()
    done = False
    moves = 0
    start = datetime.now()
    
    while not done:        
        action = agent.play(board, use_memo)
        done = board.play(action)
        done = done or check_win(board)
        moves += 1

    print(f"Max tile: {board.get_max_tile()}")
    print('Total time: {}'.format(datetime.now() - start))
    print('Total Moves: {}'.format(moves))
    print('Memo uses: ', agent.memo_counter)
    if check_win(board):
        print("WON THE GAME!!!!!!!!")
    else:
        print("BOOOOOOOOOO!!!!!!!!!")
    return check_win(board), board.get_max_tile()


# %% [markdown]
# ### Ejecucion del agente minimax con 5 juegos, heuristica compuesta, poda a los 4 niveles del arbol y considerando 5 casillas libres, con memoizacion

# %%
winrate = 0
count = 0
games = 5
results = np.zeros(games)
for i in range(games):
    won, maxTile = run_game()
    results[i] = maxTile
    count += 1
    winrate += 1 if won else 0

print(f"El winrate obtenido con {count} ejecuciones es de: {(winrate*100)/games}")


# %% [markdown]
# ### Ejecucion del agente minimax con 5 juegos, heuristica compuesta, poda a los 4 niveles del arbol y considerando 5 casillas libres, SIN memoizacion

# %%
winrate = 0
count = 0
games = 5
results = np.zeros(games)
for i in range(games):
    won, maxTile = run_game(False)
    results[i] = maxTile
    count += 1
    winrate += 1 if won else 0

print(f"El winrate obtenido con {count} ejecuciones es de: {(winrate*100)/games}")
